// mqttClient.js
require("dotenv").config();
const mqtt = require("mqtt");
const { getConnection } = require("./db");
const { getIO } = require("./socket");

const mqttHost = process.env.MQTT_HOST;
const mqttPort = Number(process.env.MQTT_PORT);
const mqttUser = process.env.MQTT_USER;
const mqttPass = process.env.MQTT_PASS;

const clientId = "NODEJS_SERVER_" + Math.random().toString(16).substr(2, 8);

const options = {
  host: mqttHost,
  port: mqttPort,
  protocol: "mqtts",
  username: mqttUser,
  password: mqttPass,
  clientId: clientId,
  rejectUnauthorized: false,
  connectTimeout: 40000,
};

console.log("⚙ MQTT Option:", options);
console.log("🔌 Đang kết nối MQTT...");

const client = mqtt.connect(options);

client.on("connect", () => {
  console.log("🚀 MQTT connected!");
  client.subscribe("data/sensor/dht22", (err) => {
    if (err) console.log("❌ Subscribe lỗi:", err);
    else console.log("📡 Đã subscribe: data/sensor/dht22");
  });
});

client.on("message", async (topic, message) => {
  console.log("📥 Nhận MQTT:", topic, message.toString());

  try {
    const data = JSON.parse(message.toString());
    const temperature = data.temperature;
    const humidity = data.humidity;

    const pool = await getConnection();

    // 1) Lưu lịch sử SensorData
    await pool
      .request()
      .input("sensorId", 1)
      .input("value", temperature)
      .query("INSERT INTO SensorData (SensorID, Value) VALUES (@sensorId, @value)");

    await pool
      .request()
      .input("sensorId", 2)
      .input("value", humidity)
      .query("INSERT INTO SensorData (SensorID, Value) VALUES (@sensorId, @value)");

    console.log("💾 SQL: Đã lưu dữ liệu vào SensorData!");

    // 2) UPDATE bảng Devices với giá trị mới nhất
    await pool
      .request()
      .input("temp", temperature)
      .input("hum", humidity)
      .query(`
        UPDATE Devices
        SET Temperature = @temp,
            Humidity = @hum,
            UpdatedAt = GETDATE()
        WHERE DeviceID = 1
      `);

    console.log("🔥 Đã cập nhật Devices!");

    // 3) Emit realtime qua Socket.IO cho Dashboard
    const io = getIO();
    if (io) {
      io.emit("sensorData", {
        temperature,
        humidity,
        timestamp: new Date().toISOString(),
      });
      // console.log("📡 Đã emit sensorData qua Socket.IO");
    }
  } catch (err) {
    console.error("❌ Lỗi xử lý MQTT:", err);
  }
});

client.on("error", (err) => console.error("❌ Lỗi MQTT:", err));
client.on("reconnect", () => console.log("♻️ MQTT reconnect..."));
client.on("close", () => console.log("🔒 MQTT closed"));

module.exports = client;
