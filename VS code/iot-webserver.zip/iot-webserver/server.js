console.log("🔥 SERVER.JS PATH:", __filename);
console.log("🔥 WORK DIR:", process.cwd());

require("dotenv").config();
const express = require("express");
const cors = require("cors");
const http = require("http");

const app = express();
const PORT = 3000;

// Middleware
app.use(cors());
app.use(express.json());

// 👉 Serve static front-end (dashboard)
app.use(express.static("public"));

const server = http.createServer(app);

// Socket.IO
const { initSocket } = require("./socket");
const io = initSocket(server);

// MQTT
require("./mqttClient");

// ROUTES API
const sensorRoutes = require("./routes/sensorRoutes");
app.use("/api", sensorRoutes);

// Start server
server.listen(PORT, () => {
  console.log(`🚀 Server đang chạy tại http://localhost:${PORT}`);
});
