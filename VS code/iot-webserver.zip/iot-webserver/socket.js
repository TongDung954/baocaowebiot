// socket.js
let io = null;

function initSocket(server) {
  const { Server } = require("socket.io");

  io = new Server(server, {
    cors: {
      origin: "*",
    },
  });

  console.log("🔌 Socket.IO initialized!");
  return io;
}

function getIO() {
  return io;
}

module.exports = { initSocket, getIO };
