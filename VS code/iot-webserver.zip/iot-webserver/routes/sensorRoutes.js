// ⭐ DEBUG: Kiểm tra file có được load hay không
console.log("🔥 sensorRoutes.js ĐANG ĐƯỢC LOAD!");

const express = require("express");
const router = express.Router();
const { getConnection } = require("../db");

// Lấy danh sách Sensors
router.get("/sensors", async (req, res) => {
  try {
    const pool = await getConnection();
    const result = await pool.request().query("SELECT * FROM Sensors");
    res.json(result.recordset);
  } catch (err) {
    res.status(500).json({ error: "Lỗi lấy danh sách sensors", detail: err.message });
  }
});

// Lấy toàn bộ dữ liệu cảm biến
router.get("/sensor-data", async (req, res) => {
  try {
    const pool = await getConnection();
    const result = await pool.request().query("SELECT * FROM SensorData ORDER BY Timestamp DESC");
    res.json(result.recordset);
  } catch (err) {
    res.status(500).json({ error: "Lỗi lấy dữ liệu sensor", detail: err.message });
  }
});

// Lấy dữ liệu NHIỆT ĐỘ + ĐỘ ẨM mới nhất
router.get("/sensor-data/latest", async (req, res) => {
  try {
    const pool = await getConnection();
    const result = await pool.request().query(`
      SELECT TOP 1 * FROM SensorData ORDER BY Timestamp DESC
    `);
    res.json(result.recordset[0]);
  } catch (err) {
    res.status(500).json({ error: "Lỗi lấy dữ liệu mới nhất", detail: err.message });
  }
});

// ⭐ DEBUG: Kiểm tra router có export đúng không
console.log("🔥 module.exports router:", router);

module.exports = router;
